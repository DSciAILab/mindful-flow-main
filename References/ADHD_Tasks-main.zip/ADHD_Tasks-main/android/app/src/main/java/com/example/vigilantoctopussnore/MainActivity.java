package com.example.vigilantoctopussnore;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
