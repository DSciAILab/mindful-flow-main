ALTER TABLE public.profiles
ADD COLUMN enable_sound_notifications BOOLEAN DEFAULT true;